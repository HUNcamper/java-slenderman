java -classpath "./out:./resources" com.prog1.slenderman.Main
