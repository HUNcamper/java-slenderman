package com.prog1.slenderman;

import com.prog1.slenderman.game.Game;

/**
 * Main osztály a játék lefuttatására
 */
public class Main {

    /**
     * Main függvény a játék lefuttatására
     * @param args Command Line argumentumok
     */
    public static void main(String[] args) {
        Game game = new Game();
    }
}
